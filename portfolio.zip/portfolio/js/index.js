document.addEventListener("DOMContentLoaded", () => {
  // ۱. منوی همبرگری موبایل
  const hamburger = document.getElementById("hamburger");
  const navMenu = document.getElementById("navMenu");
  const navLinks = document.querySelectorAll(".nav-link");

  if (hamburger && navMenu) {
    hamburger.addEventListener("click", () => {
      navMenu.classList.toggle("active");
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        navMenu.classList.remove("active");
      });
    });
  }

  // ۲. فیلتر داینامیک پروژه‌ها
  const filterBtns = document.querySelectorAll(".filter-btn");
  const projectCards = document.querySelectorAll(".project-card");

  filterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");

      const filterValue = btn.getAttribute("data-filter");

      projectCards.forEach((card) => {
        if (
          filterValue === "all" ||
          card.getAttribute("data-category") === filterValue
        ) {
          card.classList.remove("hide");
        } else {
          card.classList.add("hide");
        }
      });
    });
  });

  // ۳. انیمیشن ظهور و پر شدن درصد مهارت‌ها
  const reveals = document.querySelectorAll(".reveal");
  const progressFills = document.querySelectorAll(".progress-bar-fill");

  const revealOnScroll = () => {
    const windowHeight = window.innerHeight;

    reveals.forEach((element) => {
      const elementTop = element.getBoundingClientRect().top;
      if (elementTop < windowHeight - 100) {
        element.classList.add("active");
      }
    });

    const skillsSection = document.getElementById("skills");
    if (skillsSection) {
      const skillsTop = skillsSection.getBoundingClientRect().top;
      if (skillsTop < windowHeight - 100) {
        progressFills.forEach((fill) => {
          fill.style.width = fill.getAttribute("data-progress");
        });
      }
    }
  };

  window.addEventListener("scroll", revealOnScroll);
  revealOnScroll();
});
